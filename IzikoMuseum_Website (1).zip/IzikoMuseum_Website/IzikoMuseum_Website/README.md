# Iziko Museum Website

A responsive website companion built from the supplied Iziko Museum Android app. It uses the same warm off-white background, orange/red accent colours, serif display headings, artwork imagery and core areas: Home, Artwork, Artists, Exhibitions, Login/Register and Settings.

## Run locally

Because the collection data is loaded from a JSON file, run it through a local web server instead of opening `index.html` directly.

**Option 1 — Python**
1. Extract the ZIP.
2. Open a terminal in this folder.
3. Run `python -m http.server 8000`.
4. Open `http://localhost:8000` in your browser.

**Option 2 — VS Code**
Open the folder and use the Live Server extension on `index.html`.

## Notes
- This is a front-end website prototype; it does not automatically connect to the Android app or the app's API.
- Login/register is a browser-only demonstration using local storage. Do not enter a real password. For production, connect it to a secure backend and never store passwords in browser local storage.
- Museum artwork/artist records and supplied image assets are included locally.
