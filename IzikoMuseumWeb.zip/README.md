# Iziko Museum – Website (frontend + backend)

A web version of the Iziko Museum Android app. Same colours, fonts, screens, data and API.

```
cd server
python3 app.py            # open http://localhost:8000
python3 app.py --reset    # wipe iziko.db and re-create it from seed.json
python3 app.py --port 9000
```

Python 3.8+ only, nothing to install.

## Layout
- `server/app.py` – REST API (SQLite) **and** static file server for the website
- `server/seed.json` – artworks, artists, exhibitions
- `server/web/` – frontend (`index.html`, `style.css`, `app.js`, `images/`)

## Screens
Welcome, Log in, Register, Home (hero, Explore tiles, Now showing, Featured works), Explore Artwork
(search + category chips), Artwork detail, Discover Artists, Artist detail, Exhibitions, Settings
(account, dark mode, notifications, server address, about).

## API
Identical to the Android app's API: `/api/health`, `/api/artworks`, `/api/artworks/<id>`, `/api/categories`,
`/api/artists`, `/api/artists/<id>`, `/api/exhibitions`, `POST /api/auth/register|login|logout`, `GET /api/me`.

## Before going public
Serve over HTTPS (nginx/Caddy) and add rate limiting to login/register.
