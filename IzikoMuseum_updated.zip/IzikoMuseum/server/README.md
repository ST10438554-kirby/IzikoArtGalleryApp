# Iziko Museum API

A small REST API with a SQLite database. Python 3.8+ only, nothing to install.

```
cd server
python3 app.py            # http://0.0.0.0:8000
python3 app.py --reset    # wipe iziko.db and re-create it from seed.json
```

The database file (`iziko.db`) is created on first run and filled from `seed.json`.

## Connecting the app

| Where the app runs | Server address to use |
|---|---|
| Android emulator | `http://10.0.2.2:8000` (the default) |
| Real phone on the same Wi-Fi | `http://<your computer's IP>:8000` |

Change it in the app under **Settings > Server > Save and test**. A real phone also needs the
computer's firewall to allow port 8000.

## Endpoints

| Method | Path | Notes |
|---|---|---|
| GET | `/api/health` | `{"status":"ok"}` |
| GET | `/api/artworks` | optional `?q=text&category=Painting&featured=1` |
| GET | `/api/artworks/<id>` | |
| GET | `/api/categories` | |
| GET | `/api/artists` | |
| GET | `/api/artists/<id>` | includes that artist's `artworks` |
| GET | `/api/exhibitions` | |
| POST | `/api/auth/register` | `{"fullName","email","password"}` (password 8+ characters) |
| POST | `/api/auth/login` | `{"email","password"}` returns `{"token","user"}` |
| POST | `/api/auth/logout` | header `Authorization: Bearer <token>` |
| GET | `/api/me` | header `Authorization: Bearer <token>` |

Errors are always `{"error": "message"}` with a matching HTTP status.

## Editing the data

Edit `seed.json`, then run `python3 app.py --reset`. Each artwork, artist and exhibition has an
`image` field holding the name of a drawable in `app/src/main/res/drawable-nodpi`
(for example `"butcher_boys"`), or `null`.

The app keeps a copy of the same data in `app/src/main/assets/museum_seed.json`, which it shows if
the server cannot be reached. After editing `seed.json`, copy it over:

```
cp server/seed.json app/src/main/assets/museum_seed.json
```

## Before going public

- Serve it over HTTPS (behind nginx/Caddy or a host that provides it), then remove
  `android:usesCleartextTraffic="true"` from the manifest.
- Add rate limiting to the login and register endpoints.
