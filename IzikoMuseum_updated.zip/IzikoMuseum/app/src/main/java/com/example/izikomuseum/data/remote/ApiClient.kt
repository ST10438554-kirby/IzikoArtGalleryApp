package com.example.izikomuseum.data.remote

import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import org.json.JSONTokener

/**
 * Minimal JSON-over-HTTP client for the Iziko API (see the /server folder).
 * Every function blocks, so call them from [Background.execute], never from the main thread.
 */
object ApiClient {
    /** The Android emulator reaches the computer it runs on at 10.0.2.2. */
    const val DEFAULT_URL = "http://10.0.2.2:8000"

    @Volatile var baseUrl: String = DEFAULT_URL

    /** Set after a successful login and sent with every request as a Bearer token. */
    @Volatile var token: String? = null

    class ApiException(message: String, val status: Int = 0) : Exception(message)

    fun getArray(path: String): JSONArray =
        request("GET", path, null, token) as? JSONArray ?: throw unexpected()

    fun getObject(path: String): JSONObject =
        request("GET", path, null, token) as? JSONObject ?: throw unexpected()

    fun postObject(path: String, body: JSONObject?, authToken: String? = token): JSONObject =
        request("POST", path, body, authToken) as? JSONObject ?: throw unexpected()

    private fun unexpected() = ApiException("The server sent a response the app could not read.")

    private fun request(method: String, path: String, body: JSONObject?, authToken: String?): Any {
        var connection: HttpURLConnection? = null
        try {
            connection = URL(baseUrl.trimEnd('/') + path).openConnection() as HttpURLConnection
            connection.requestMethod = method
            connection.connectTimeout = 4_000
            connection.readTimeout = 8_000
            connection.setRequestProperty("Accept", "application/json")
            if (authToken != null) connection.setRequestProperty("Authorization", "Bearer $authToken")
            if (body != null) {
                connection.doOutput = true
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            }
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (status !in 200..299) {
                val message = try { JSONObject(text).optString("error") } catch (e: JSONException) { "" }
                throw ApiException(message.ifBlank { "The server returned an error ($status)." }, status)
            }
            return JSONTokener(text).nextValue()
        } catch (e: ApiException) {
            throw e
        } catch (e: JSONException) {
            throw unexpected()
        } catch (e: IOException) {
            throw ApiException("Can't reach the server. Check your connection and the server address in Settings.")
        } catch (e: ClassCastException) {
            throw ApiException("The server address must start with http:// or https://.")
        } finally {
            connection?.disconnect()
        }
    }
}
