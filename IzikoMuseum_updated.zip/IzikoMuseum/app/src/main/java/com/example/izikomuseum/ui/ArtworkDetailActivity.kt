package com.example.izikomuseum.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.izikomuseum.R
import com.example.izikomuseum.data.repository.MuseumRepository

class ArtworkDetailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_artwork_detail)

        MuseumRepository.ensureLoaded(this) {
            if (isAlive()) showArtwork()
        }
    }

    private fun showArtwork() {
        val artwork = MuseumRepository.getArtwork(intent.getIntExtra(EXTRA_ID, -1))
        if (artwork == null) {
            Toast.makeText(this, "Sorry, that artwork could not be found.", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        // Show the real image when we have one; otherwise keep the colour banner.
        val image = findViewById<ImageView>(R.id.ivDetailImage)
        val hasImage = image.showImage(artwork.image)
        if (hasImage) image.contentDescription = "${artwork.title} by ${artwork.artistName}"
        image.visibility = View.VISIBLE
        findViewById<View>(R.id.cardDetailImage).visibility = if (hasImage) View.VISIBLE else View.GONE
        findViewById<View>(R.id.vDetailBanner).visibility = if (hasImage) View.GONE else View.VISIBLE

        findViewById<TextView>(R.id.tvDetailCategory).text = artwork.category.uppercase()
        findViewById<TextView>(R.id.tvDetailTitle).text = artwork.title
        findViewById<TextView>(R.id.tvDetailArtist).apply {
            text = artwork.artistName
            setOnClickListener {
                startActivity(
                    Intent(this@ArtworkDetailActivity, ArtistDetailActivity::class.java)
                        .putExtra(ArtistDetailActivity.EXTRA_ID, artwork.artistId)
                )
            }
        }
        findViewById<TextView>(R.id.tvDetailDescription).text = artwork.description

        val facts = findViewById<LinearLayout>(R.id.llFacts)
        addFact(facts, "Date", artwork.date)
        addFact(facts, "Medium", artwork.medium)
        addFact(facts, "Size", artwork.dimensions)
        addFact(facts, "Collection", artwork.acquisition)
    }

    companion object {
        const val EXTRA_ID = "artwork_id"
    }
}
