package com.example.izikomuseum

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate
import com.example.izikomuseum.data.remote.ApiClient
import com.example.izikomuseum.data.repository.SettingsRepository

/** Runs once when the app starts: points the API client at the saved server and re-applies dark mode. */
class IzikoApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        ApiClient.baseUrl = SettingsRepository(this).serverUrl
        SettingsRepository(this).darkMode?.let { dark ->
            AppCompatDelegate.setDefaultNightMode(
                if (dark) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
            )
        }
    }
}
