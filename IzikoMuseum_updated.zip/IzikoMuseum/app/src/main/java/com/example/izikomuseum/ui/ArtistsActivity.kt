package com.example.izikomuseum.ui

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.izikomuseum.R
import com.example.izikomuseum.data.repository.MuseumRepository

class ArtistsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_artists)

        MuseumRepository.ensureLoaded(this) {
            if (isAlive()) showArtists()
        }
    }

    private fun showArtists() {
        val list = findViewById<LinearLayout>(R.id.llArtistList)
        list.removeAllViews()
        MuseumRepository.getArtists().forEach { artist ->
            val card = layoutInflater.inflate(R.layout.item_artist, list, false)
            card.findViewById<TextView>(R.id.tvArtistName).text = artist.name
            val details = listOf(artist.lifespan, artist.origin).filter { it.isNotBlank() }.joinToString(", ")
            card.findViewById<TextView>(R.id.tvArtistDetails).text = details
            val count = MuseumRepository.artworksBy(artist.id).size
            card.findViewById<TextView>(R.id.tvArtistWorks).text =
                if (count == 1) "1 artwork in this app" else "$count artworks in this app"

            card.findViewById<TextView>(R.id.tvArtistInitials).text = initialsOf(artist.name)
            val portrait = card.findViewById<ImageView>(R.id.ivArtistImage)
            if (portrait.showImage(artist.image)) portrait.contentDescription = artist.name

            card.setOnClickListener {
                startActivity(
                    Intent(this, ArtistDetailActivity::class.java)
                        .putExtra(ArtistDetailActivity.EXTRA_ID, artist.id)
                )
            }
            list.addView(card)
        }
    }
}
