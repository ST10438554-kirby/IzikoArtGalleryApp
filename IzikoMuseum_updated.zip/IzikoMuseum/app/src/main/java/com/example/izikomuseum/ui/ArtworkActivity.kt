package com.example.izikomuseum.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import com.example.izikomuseum.R
import com.example.izikomuseum.data.repository.MuseumRepository
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup

class ArtworkActivity : AppCompatActivity() {

    private var selectedCategory: String? = null
    private lateinit var list: LinearLayout
    private lateinit var empty: TextView
    private lateinit var search: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_artwork)

        list = findViewById(R.id.llArtworkList)
        empty = findViewById(R.id.tvArtworkEmpty)
        search = findViewById(R.id.etArtworkSearch)

        MuseumRepository.ensureLoaded(this) {
            if (isAlive()) setUpScreen()
        }
    }

    private fun setUpScreen() {
        val group = findViewById<ChipGroup>(R.id.chipGroupCategories)
        (listOf("All") + MuseumRepository.categories()).forEach { name ->
            val chip = layoutInflater.inflate(R.layout.item_chip, group, false) as Chip
            chip.text = name
            chip.isChecked = name == "All"
            group.addView(chip)
        }
        group.setOnCheckedStateChangeListener { g, checkedIds ->
            val chip = checkedIds.firstOrNull()?.let { g.findViewById<Chip>(it) }
            selectedCategory = chip?.text?.toString()?.takeIf { it != "All" }
            render()
        }
        search.doAfterTextChanged { render() }
        render()
    }

    private fun render() {
        val results = MuseumRepository.searchArtworks(search.text.toString(), selectedCategory)
        list.removeAllViews()
        results.forEach { artwork ->
            val card = layoutInflater.inflate(R.layout.item_artwork, list, false)
            card.findViewById<TextView>(R.id.tvArtworkTitle).text = artwork.title
            card.findViewById<TextView>(R.id.tvArtworkMeta).text = "${artwork.artistName}, ${artwork.date}"
            card.findViewById<TextView>(R.id.tvArtworkCategory).text = artwork.category.uppercase()
            val medium = card.findViewById<TextView>(R.id.tvArtworkMedium)
            if (artwork.medium.isNullOrBlank()) {
                medium.visibility = View.GONE
            } else {
                medium.text = artwork.medium
            }
            bindArtworkThumb(card, artwork.image, artwork.title)
            card.setOnClickListener {
                startActivity(
                    Intent(this, ArtworkDetailActivity::class.java)
                        .putExtra(ArtworkDetailActivity.EXTRA_ID, artwork.id)
                )
            }
            list.addView(card)
        }
        empty.visibility = if (results.isEmpty()) View.VISIBLE else View.GONE
    }
}
