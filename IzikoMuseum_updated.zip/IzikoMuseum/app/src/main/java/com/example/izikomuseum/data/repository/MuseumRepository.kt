package com.example.izikomuseum.data.repository

import android.content.Context
import com.example.izikomuseum.data.model.Artist
import com.example.izikomuseum.data.model.Artwork
import com.example.izikomuseum.data.model.Exhibition
import com.example.izikomuseum.data.remote.ApiClient
import com.example.izikomuseum.data.remote.Background
import org.json.JSONArray
import org.json.JSONObject

/**
 * Museum data. It is loaded from the Iziko API once and kept in memory; searching and filtering
 * then happen on the phone. If the server cannot be reached, the app falls back to the copy of the
 * data bundled in assets/museum_seed.json, so the screens still work ([isOffline] tells you which).
 *
 * Screens call [ensureLoaded] first and then use the functions at the bottom of this object.
 */
object MuseumRepository {

    private class Snapshot(
        val artists: List<Artist>,
        val artworks: List<Artwork>,
        val exhibitions: List<Exhibition>
    )

    private const val RETRY_AFTER_MS = 15_000L

    private var artists: List<Artist> = emptyList()
    private var artworks: List<Artwork> = emptyList()
    private var exhibitions: List<Exhibition> = emptyList()

    private var loaded = false
    private var loading = false
    private var lastAttempt = 0L
    private val waiting = mutableListOf<() -> Unit>()

    /** True while the screens are showing the bundled copy because the server could not be reached. */
    var isOffline = false
        private set

    /** Calls [onReady] on the main thread once data is available. */
    fun ensureLoaded(context: Context, onReady: () -> Unit) {
        if (loaded) {
            onReady()
            // Quietly try the server again so the next screen gets live data.
            if (isOffline && System.currentTimeMillis() - lastAttempt > RETRY_AFTER_MS) {
                load(context.applicationContext)
            }
            return
        }
        waiting.add(onReady)
        load(context.applicationContext)
    }

    /** Forces the next [ensureLoaded] to ask the server again (used after the server address changes). */
    fun invalidate() {
        loaded = false
    }

    private fun load(appContext: Context) {
        if (loading) return
        loading = true
        lastAttempt = System.currentTimeMillis()
        Background.execute({ fetchFromServer() }) { outcome ->
            loading = false
            val fresh = outcome.getOrNull()
            if (fresh != null) {
                store(fresh)
                isOffline = false
                loaded = true
            } else if (!loaded) {
                store(runCatching { readBundledCopy(appContext) }.getOrElse { Snapshot(emptyList(), emptyList(), emptyList()) })
                isOffline = true
                loaded = true
            }
            val callbacks = waiting.toList()
            waiting.clear()
            callbacks.forEach { it() }
        }
    }

    private fun store(snapshot: Snapshot) {
        artists = snapshot.artists
        artworks = snapshot.artworks
        exhibitions = snapshot.exhibitions
    }

    private fun fetchFromServer() = Snapshot(
        parseArtists(ApiClient.getArray("/api/artists")),
        parseArtworks(ApiClient.getArray("/api/artworks")),
        parseExhibitions(ApiClient.getArray("/api/exhibitions"))
    )

    private fun readBundledCopy(context: Context): Snapshot {
        val text = context.assets.open("museum_seed.json").bufferedReader().use { it.readText() }
        val root = JSONObject(text)
        return Snapshot(
            parseArtists(root.getJSONArray("artists")),
            parseArtworks(root.getJSONArray("artworks")),
            parseExhibitions(root.getJSONArray("exhibitions"))
        )
    }

    // ---- JSON parsing

    private fun <T> JSONArray.mapObjects(transform: (JSONObject) -> T): List<T> =
        List(length()) { transform(getJSONObject(it)) }

    /** Returns null for a missing, null or blank value. */
    private fun JSONObject.stringOrNull(key: String): String? =
        if (isNull(key)) null else optString(key).ifBlank { null }

    private fun parseArtists(array: JSONArray) = array.mapObjects { o ->
        Artist(
            id = o.getInt("id"),
            name = o.getString("name"),
            lifespan = o.optString("lifespan", ""),
            origin = o.optString("origin", ""),
            biography = o.optString("biography", ""),
            image = o.stringOrNull("image")
        )
    }

    private fun parseArtworks(array: JSONArray) = array.mapObjects { o ->
        Artwork(
            id = o.getInt("id"),
            title = o.getString("title"),
            artistId = o.getInt("artistId"),
            artistName = o.getString("artistName"),
            category = o.getString("category"),
            date = o.optString("date", ""),
            medium = o.stringOrNull("medium"),
            dimensions = o.stringOrNull("dimensions"),
            acquisition = o.stringOrNull("acquisition"),
            description = o.optString("description", ""),
            image = o.stringOrNull("image"),
            featured = o.optBoolean("featured", false)
        )
    }

    private fun parseExhibitions(array: JSONArray) = array.mapObjects { o ->
        Exhibition(
            id = o.getInt("id"),
            title = o.getString("title"),
            dates = o.optString("dates", ""),
            status = o.optString("status", ""),
            curator = o.stringOrNull("curator"),
            summary = o.optString("summary", ""),
            image = o.stringOrNull("image")
        )
    }

    // ---- What the screens use

    fun searchArtworks(query: String, category: String?): List<Artwork> {
        val q = query.trim().lowercase()
        return artworks.filter { a ->
            val categoryOk = category == null || a.category.equals(category, ignoreCase = true)
            val queryOk = q.isEmpty() || a.title.lowercase().contains(q) || a.artistName.lowercase().contains(q)
            categoryOk && queryOk
        }
    }

    fun categories(): List<String> = artworks.map { it.category }.distinct().sorted()
    fun getArtwork(id: Int): Artwork? = artworks.firstOrNull { it.id == id }
    fun featuredArtworks(): List<Artwork> = artworks.filter { it.featured }
    fun getArtists(): List<Artist> = artists
    fun getArtist(id: Int): Artist? = artists.firstOrNull { it.id == id }
    fun artworksBy(artistId: Int): List<Artwork> = artworks.filter { it.artistId == artistId }
    fun getExhibitions(): List<Exhibition> = exhibitions
}
