package com.example.izikomuseum.data.repository

import android.content.Context
import com.example.izikomuseum.data.remote.ApiClient

/** App settings saved on the phone. They can also be saved per user once the API is connected. */
class SettingsRepository(context: Context) {
    private val prefs = context.getSharedPreferences("iziko_settings", Context.MODE_PRIVATE)

    /** null means the person has not chosen yet, so the app follows the phone's setting. */
    var darkMode: Boolean?
        get() = if (prefs.contains(KEY_DARK)) prefs.getBoolean(KEY_DARK, false) else null
        set(value) {
            if (value == null) prefs.edit().remove(KEY_DARK).apply()
            else prefs.edit().putBoolean(KEY_DARK, value).apply()
        }

    var notificationsEnabled: Boolean
        get() = prefs.getBoolean(KEY_NOTIFICATIONS, true)
        set(value) = prefs.edit().putBoolean(KEY_NOTIFICATIONS, value).apply()

    /** Where the Iziko API runs. 10.0.2.2 reaches the computer from the Android emulator. */
    var serverUrl: String
        get() = prefs.getString(KEY_SERVER, null) ?: ApiClient.DEFAULT_URL
        set(value) = prefs.edit().putString(KEY_SERVER, value.trim().trimEnd('/')).apply()

    private companion object {
        const val KEY_SERVER = "server_url"
        const val KEY_DARK = "dark_mode"
        const val KEY_NOTIFICATIONS = "notifications"
    }
}
