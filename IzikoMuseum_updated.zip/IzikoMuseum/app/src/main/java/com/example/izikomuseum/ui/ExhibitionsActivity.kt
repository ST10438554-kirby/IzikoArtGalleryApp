package com.example.izikomuseum.ui

import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.izikomuseum.R
import com.example.izikomuseum.data.repository.MuseumRepository

class ExhibitionsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_exhibitions)

        MuseumRepository.ensureLoaded(this) {
            if (isAlive()) showExhibitions()
        }
    }

    private fun showExhibitions() {
        val list = findViewById<LinearLayout>(R.id.llExhibitionList)
        list.removeAllViews()
        MuseumRepository.getExhibitions().forEach { exhibition ->
            val card = layoutInflater.inflate(R.layout.item_exhibition, list, false)
            card.findViewById<TextView>(R.id.tvExhibitionStatus).text = exhibition.status.uppercase()
            card.findViewById<TextView>(R.id.tvExhibitionTitle).text = exhibition.title
            card.findViewById<TextView>(R.id.tvExhibitionDates).text = exhibition.dates

            val image = card.findViewById<ImageView>(R.id.ivExhibitionImage)
            val hasImage = image.showImage(exhibition.image)
            if (hasImage) image.contentDescription = exhibition.title
            card.findViewById<View>(R.id.cardExhibitionImage).visibility = if (hasImage) View.VISIBLE else View.GONE

            val curator = card.findViewById<TextView>(R.id.tvExhibitionCurator)
            if (exhibition.curator.isNullOrBlank()) {
                curator.visibility = View.GONE
            } else {
                curator.text = "Curator: ${exhibition.curator}"
            }
            card.findViewById<TextView>(R.id.tvExhibitionSummary).text = exhibition.summary
            list.addView(card)
        }
    }
}
