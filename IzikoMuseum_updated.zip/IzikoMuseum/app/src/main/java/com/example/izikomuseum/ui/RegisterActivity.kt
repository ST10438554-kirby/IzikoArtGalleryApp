package com.example.izikomuseum.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.izikomuseum.R
import com.example.izikomuseum.data.repository.AuthRepository

class RegisterActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)
        val name = findViewById<EditText>(R.id.etRegisterName)
        val email = findViewById<EditText>(R.id.etRegisterEmail)
        val password = findViewById<EditText>(R.id.etRegisterPassword)
        val confirm = findViewById<EditText>(R.id.etConfirmPassword)
        val error = findViewById<TextView>(R.id.tvRegisterError)
        val registerButton = findViewById<Button>(R.id.btnRegister)
        registerButton.setOnClickListener {
            if (name.text.isBlank() || email.text.isBlank() || password.text.isBlank() || confirm.text.isBlank()) {
                error.text = "Please complete all fields."; error.visibility = View.VISIBLE; return@setOnClickListener
            }
            if (password.text.toString() != confirm.text.toString()) {
                error.text = "Your passwords do not match."; error.visibility = View.VISIBLE; return@setOnClickListener
            }
            error.visibility = View.GONE
            registerButton.isEnabled = false
            AuthRepository.register(name.text.toString(), email.text.toString(), password.text.toString()) { result ->
                if (!isAlive()) return@register
                when (result) {
                    is AuthRepository.Result.Success -> { startActivity(Intent(this, LoginActivity::class.java)); finish() }
                    is AuthRepository.Result.Error -> {
                        registerButton.isEnabled = true
                        error.text = result.message; error.visibility = View.VISIBLE
                    }
                }
            }
        }
        findViewById<TextView>(R.id.tvGoLogin).setOnClickListener { finish() }
    }
}
