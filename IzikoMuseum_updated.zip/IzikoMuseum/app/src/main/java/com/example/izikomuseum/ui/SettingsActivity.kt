package com.example.izikomuseum.ui

import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.example.izikomuseum.R
import com.example.izikomuseum.data.remote.ApiClient
import com.example.izikomuseum.data.remote.Background
import com.example.izikomuseum.data.repository.AuthRepository
import com.example.izikomuseum.data.repository.MuseumRepository
import com.example.izikomuseum.data.repository.SettingsRepository
import com.google.android.material.switchmaterial.SwitchMaterial

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val settings = SettingsRepository(this)

        val user = AuthRepository.currentUser
        findViewById<TextView>(R.id.tvSettingsName).text = user?.fullName ?: "Guest"
        findViewById<TextView>(R.id.tvSettingsEmail).text = user?.email ?: "Not signed in"

        // Show the current values first, then start listening, so setting them does not trigger the listeners.
        val darkSwitch = findViewById<SwitchMaterial>(R.id.switchDarkMode)
        val isNight = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        darkSwitch.isChecked = isNight
        darkSwitch.setOnCheckedChangeListener { _, checked ->
            settings.darkMode = checked
            AppCompatDelegate.setDefaultNightMode(
                if (checked) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
            )
        }

        val notificationSwitch = findViewById<SwitchMaterial>(R.id.switchNotifications)
        notificationSwitch.isChecked = settings.notificationsEnabled
        notificationSwitch.setOnCheckedChangeListener { _, checked ->
            settings.notificationsEnabled = checked
        }

        val serverField = findViewById<EditText>(R.id.etServerUrl)
        val serverStatus = findViewById<TextView>(R.id.tvServerStatus)
        serverField.setText(settings.serverUrl)
        findViewById<Button>(R.id.btnSaveServer).setOnClickListener {
            val url = serverField.text.toString().trim().trimEnd('/')
            if (!url.startsWith("http://") && !url.startsWith("https://")) {
                serverStatus.text = "The address must start with http:// or https://"
                return@setOnClickListener
            }
            settings.serverUrl = url
            ApiClient.baseUrl = url
            MuseumRepository.invalidate()
            serverStatus.text = "Checking..."
            Background.execute({ ApiClient.getObject("/api/health") }) { outcome ->
                if (!isAlive()) return@execute
                serverStatus.text = if (outcome.isSuccess) "Connected to the server."
                else outcome.exceptionOrNull()?.message ?: "Could not connect."
            }
        }

        val version = try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: "1.0"
        } catch (e: Exception) {
            "1.0"
        }
        findViewById<TextView>(R.id.tvSettingsVersion).text = "Version $version"

        findViewById<Button>(R.id.btnSettingsLogout).setOnClickListener {
            AuthRepository.logout()
            val intent = Intent(this, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }
    }
}
