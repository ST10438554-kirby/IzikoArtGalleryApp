package com.example.izikomuseum.data.remote

import android.os.Handler
import android.os.Looper
import java.util.concurrent.Executors

/** Runs slow work (network calls) off the main thread and hands the result back on it. */
object Background {
    private val executor = Executors.newFixedThreadPool(3)
    private val mainHandler = Handler(Looper.getMainLooper())

    fun <T> execute(work: () -> T, onDone: (Result<T>) -> Unit) {
        executor.execute {
            val outcome = runCatching(work)
            mainHandler.post { onDone(outcome) }
        }
    }
}
