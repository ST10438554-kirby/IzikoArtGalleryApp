package com.example.izikomuseum.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.izikomuseum.R
import com.example.izikomuseum.data.repository.MuseumRepository

class ArtistDetailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_artist_detail)

        MuseumRepository.ensureLoaded(this) {
            if (isAlive()) showArtist()
        }
    }

    private fun showArtist() {
        val artist = MuseumRepository.getArtist(intent.getIntExtra(EXTRA_ID, -1))
        if (artist == null) {
            Toast.makeText(this, "Sorry, that artist could not be found.", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        findViewById<TextView>(R.id.tvArtistDetailName).text = artist.name
        findViewById<TextView>(R.id.tvArtistDetailInfo).text =
            listOf(artist.lifespan, artist.origin).filter { it.isNotBlank() }.joinToString(", ")
        findViewById<TextView>(R.id.tvArtistDetailBio).text = artist.biography
        findViewById<TextView>(R.id.tvArtistDetailInitials).text = initialsOf(artist.name)
        val portrait = findViewById<ImageView>(R.id.ivArtistDetailImage)
        if (portrait.showImage(artist.image)) portrait.contentDescription = artist.name

        val works = MuseumRepository.artworksBy(artist.id)
        val list = findViewById<LinearLayout>(R.id.llArtistWorks)
        list.removeAllViews()
        findViewById<TextView>(R.id.tvArtistWorksHeading).visibility =
            if (works.isEmpty()) View.GONE else View.VISIBLE
        works.forEach { artwork ->
            val card = layoutInflater.inflate(R.layout.item_artwork, list, false)
            card.findViewById<TextView>(R.id.tvArtworkTitle).text = artwork.title
            card.findViewById<TextView>(R.id.tvArtworkMeta).text = artwork.date
            card.findViewById<TextView>(R.id.tvArtworkCategory).text = artwork.category.uppercase()
            card.findViewById<TextView>(R.id.tvArtworkMedium).visibility = View.GONE
            bindArtworkThumb(card, artwork.image, artwork.title)
            card.setOnClickListener {
                startActivity(
                    Intent(this, ArtworkDetailActivity::class.java)
                        .putExtra(ArtworkDetailActivity.EXTRA_ID, artwork.id)
                )
            }
            list.addView(card)
        }
    }

    companion object {
        const val EXTRA_ID = "artist_id"
    }
}
