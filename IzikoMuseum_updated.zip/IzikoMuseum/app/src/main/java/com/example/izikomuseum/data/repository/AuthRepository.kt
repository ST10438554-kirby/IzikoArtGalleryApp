package com.example.izikomuseum.data.repository

import android.util.Patterns
import com.example.izikomuseum.data.model.User
import com.example.izikomuseum.data.remote.ApiClient
import com.example.izikomuseum.data.remote.Background
import org.json.JSONObject

/**
 * Registration and sign-in through the Iziko API. The server stores a salted hash of the password;
 * the phone only keeps the session token (in memory) and the signed-in person's name and email.
 * Results are delivered on the main thread.
 */
object AuthRepository {

    /** The signed-in user, or null when nobody is signed in. */
    var currentUser: User? = null
        private set

    sealed class Result {
        data class Success(val user: User) : Result()
        data class Error(val message: String) : Result()
    }

    fun register(fullName: String, email: String, password: String, onResult: (Result) -> Unit) {
        val name = fullName.trim()
        val cleanEmail = email.trim().lowercase()
        if (name.isBlank()) { onResult(Result.Error("Please enter your full name.")); return }
        if (!Patterns.EMAIL_ADDRESS.matcher(cleanEmail).matches()) { onResult(Result.Error("Please enter a valid email address.")); return }
        if (password.length < 8) { onResult(Result.Error("Use a password with at least 8 characters.")); return }

        val body = JSONObject().put("fullName", name).put("email", cleanEmail).put("password", password)
        Background.execute({
            parseUser(ApiClient.postObject("/api/auth/register", body, authToken = null))
        }) { outcome ->
            onResult(outcome.fold({ Result.Success(it) }, { Result.Error(messageOf(it)) }))
        }
    }

    fun login(email: String, password: String, onResult: (Result) -> Unit) {
        val body = JSONObject().put("email", email.trim().lowercase()).put("password", password)
        Background.execute({
            val json = ApiClient.postObject("/api/auth/login", body, authToken = null)
            val user = parseUser(json)
            ApiClient.token = json.getString("token")
            user
        }) { outcome ->
            onResult(outcome.fold(
                { user -> currentUser = user; Result.Success(user) },
                { Result.Error(messageOf(it)) }
            ))
        }
    }

    fun logout() {
        val oldToken = ApiClient.token
        ApiClient.token = null
        currentUser = null
        if (oldToken != null) {
            // Tell the server to end the session. If this fails the token simply expires on its own.
            Background.execute({ ApiClient.postObject("/api/auth/logout", null, authToken = oldToken) }) { }
        }
    }

    private fun parseUser(json: JSONObject): User {
        val user = json.getJSONObject("user")
        return User(user.getString("fullName"), user.getString("email"))
    }

    private fun messageOf(error: Throwable): String =
        if (error is ApiClient.ApiException) error.message ?: GENERIC_ERROR else GENERIC_ERROR

    private const val GENERIC_ERROR = "Something went wrong. Please try again."
}
