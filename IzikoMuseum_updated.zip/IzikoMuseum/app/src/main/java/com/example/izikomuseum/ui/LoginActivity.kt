package com.example.izikomuseum.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.izikomuseum.R
import com.example.izikomuseum.data.repository.AuthRepository

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        val email = findViewById<EditText>(R.id.etLoginEmail)
        val password = findViewById<EditText>(R.id.etLoginPassword)
        val error = findViewById<TextView>(R.id.tvLoginError)
        val loginButton = findViewById<Button>(R.id.btnLogin)
        loginButton.setOnClickListener {
            if (email.text.isBlank() || password.text.isBlank()) {
                error.text = "Please enter your email and password."; error.visibility = View.VISIBLE; return@setOnClickListener
            }
            error.visibility = View.GONE
            loginButton.isEnabled = false
            AuthRepository.login(email.text.toString(), password.text.toString()) { result ->
                if (!isAlive()) return@login
                when (result) {
                    is AuthRepository.Result.Success -> { startActivity(Intent(this, HomeActivity::class.java)); finish() }
                    is AuthRepository.Result.Error -> {
                        loginButton.isEnabled = true
                        error.text = result.message; error.visibility = View.VISIBLE
                    }
                }
            }
        }
        findViewById<TextView>(R.id.tvGoRegister).setOnClickListener { startActivity(Intent(this, RegisterActivity::class.java)) }
        findViewById<Button>(R.id.btnGoogleLogin).setOnClickListener {
            error.text = "Single sign-on is not connected yet."; error.visibility = View.VISIBLE
        }
    }
}
