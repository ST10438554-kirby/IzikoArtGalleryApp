package com.example.izikomuseum.ui

import android.app.Activity
import android.content.Context
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.example.izikomuseum.R

/** Adds a "label: value" row to a container. Rows with no value are skipped. */
internal fun Activity.addFact(container: LinearLayout, label: String, value: String?) {
    if (value.isNullOrBlank()) return
    val row = layoutInflater.inflate(R.layout.item_fact, container, false)
    row.findViewById<TextView>(R.id.tvFactLabel).text = label
    row.findViewById<TextView>(R.id.tvFactValue).text = value
    container.addView(row)
}

/** False once the screen is closing, so late network results are not drawn onto a dead screen. */
internal fun Activity.isAlive(): Boolean = !isFinishing && !isDestroyed

/** Finds a bundled drawable by name (the API sends names such as "butcher_boys"). 0 if there is none. */
internal fun Context.drawableIdFor(name: String?): Int =
    if (name.isNullOrBlank()) 0 else resources.getIdentifier(name, "drawable", packageName)

/** Shows the named drawable. Hides the view and returns false when the name is empty or unknown. */
internal fun ImageView.showImage(name: String?): Boolean {
    val id = context.drawableIdFor(name)
    return if (id != 0) {
        setImageResource(id)
        visibility = View.VISIBLE
        true
    } else {
        setImageDrawable(null)
        visibility = View.GONE
        false
    }
}

/** Fills the thumbnail in an item_artwork card, or hides the thumbnail when the work has no image. */
internal fun Activity.bindArtworkThumb(card: View, imageName: String?, description: String) {
    val image = card.findViewById<ImageView>(R.id.ivArtworkImage)
    val shown = image.showImage(imageName)
    if (shown) image.contentDescription = description
    card.findViewById<View>(R.id.cardArtworkThumb).visibility = if (shown) View.VISIBLE else View.GONE
}

/** "Anton van Wouw" becomes "AV". Shown on the artist avatar when there is no portrait. */
internal fun initialsOf(name: String): String =
    name.split(" ").filter { it.isNotBlank() }.take(2).map { it.first().uppercaseChar() }.joinToString("")
