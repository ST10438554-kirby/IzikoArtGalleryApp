package com.example.izikomuseum.data.model

/** The signed-in person. Passwords are never stored on the phone; the server keeps a salted hash. */
data class User(
    val fullName: String,
    val email: String
)
