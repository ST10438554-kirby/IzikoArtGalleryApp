package com.example.izikomuseum.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.izikomuseum.R
import com.example.izikomuseum.data.repository.AuthRepository
import com.example.izikomuseum.data.repository.MuseumRepository

class HomeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        val firstName = AuthRepository.currentUser?.fullName?.trim()?.substringBefore(' ').orEmpty()
        findViewById<TextView>(R.id.tvHomeGreeting).text =
            if (firstName.isBlank()) "Welcome" else "Welcome, $firstName"

        findViewById<View>(R.id.btnArtwork).setOnClickListener {
            startActivity(Intent(this, ArtworkActivity::class.java))
        }
        findViewById<View>(R.id.btnArtists).setOnClickListener {
            startActivity(Intent(this, ArtistsActivity::class.java))
        }
        findViewById<View>(R.id.btnExhibitions).setOnClickListener {
            startActivity(Intent(this, ExhibitionsActivity::class.java))
        }
        findViewById<View>(R.id.cardHomeExhibition).setOnClickListener {
            startActivity(Intent(this, ExhibitionsActivity::class.java))
        }
        findViewById<View>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        findViewById<Button>(R.id.btnHomeLogout).setOnClickListener {
            AuthRepository.logout()
            val intent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            }
            startActivity(intent)
            finish()
        }

        MuseumRepository.ensureLoaded(this) {
            if (isAlive()) showMuseumContent()
        }
    }

    /** Fills the "Now showing" card and the featured works once the data has loaded. */
    private fun showMuseumContent() {
        findViewById<View>(R.id.tvHomeOffline).visibility =
            if (MuseumRepository.isOffline) View.VISIBLE else View.GONE

        val exhibition = MuseumRepository.getExhibitions().firstOrNull()
        val exhibitionCard = findViewById<View>(R.id.cardHomeExhibition)
        if (exhibition == null) {
            exhibitionCard.visibility = View.GONE
        } else {
            exhibitionCard.visibility = View.VISIBLE
            val image = findViewById<ImageView>(R.id.ivHomeExhibition)
            if (image.showImage(exhibition.image)) image.contentDescription = exhibition.title
            findViewById<TextView>(R.id.tvHomeExhibitionStatus).text = exhibition.status.uppercase()
            findViewById<TextView>(R.id.tvHomeExhibitionTitle).text = exhibition.title
            findViewById<TextView>(R.id.tvHomeExhibitionDates).text = exhibition.dates
        }

        val row = findViewById<LinearLayout>(R.id.llFeatured)
        row.removeAllViews()
        MuseumRepository.featuredArtworks().forEach { artwork ->
            val card = layoutInflater.inflate(R.layout.item_featured, row, false)
            val image = card.findViewById<ImageView>(R.id.ivFeaturedImage)
            image.showImage(artwork.image)
            image.visibility = View.VISIBLE
            image.contentDescription = artwork.title
            card.findViewById<TextView>(R.id.tvFeaturedTitle).text = artwork.title
            card.findViewById<TextView>(R.id.tvFeaturedArtist).text = artwork.artistName
            card.setOnClickListener {
                startActivity(
                    Intent(this, ArtworkDetailActivity::class.java)
                        .putExtra(ArtworkDetailActivity.EXTRA_ID, artwork.id)
                )
            }
            row.addView(card)
        }
        findViewById<View>(R.id.llHomeLoaded).visibility = View.VISIBLE
    }
}
